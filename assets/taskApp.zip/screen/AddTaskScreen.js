import React,{useState,useEffect} from "react";
import { SafeAreaView, StyleSheet, TextInput,ScrollView } from "react-native";
import { theme } from "../core/theme";
import Buttonn from "../components/Buttonn";
import Todo from "../components/Todo";
import TodoList from "../components/TodoList";


const AddTaskScreen = (props) => {
  // const [Task, onChangeTask] = React.useState(null);
  // const [TaskDetails, onChangeDetails] = React.useState(null);


  const [title, setTitle] = useState("");

  // iniitalize empty object todo
  const [todo, setTodo] = useState({});

  // Initalize empty array to store todos
  const [todos, setTodos] = useState([]);

  // function to add todo object in todo list
  const addTodo = () => {
    if (title.length > 0) {
      // Add todo to the list
      setTodos([...todos, { key: Date.now(), name: title, isChecked: false }]);
      // clear the value of the textfield
      setTitle("");
    }
  };


  // function to delete todo from the todo list
  const deleteTodo = id => {
    // loop through todo list and return todos that don't match the id
    // update the state using setTodos function
    setTodos(todos.filter(todo => {
      return todo.key !== id;
    }));
  };
  return (
    <SafeAreaView>

      <TextInput
          placeholder="Add a Task"
          value={title}
          onChangeText={value => setTitle(value)}
          style={styles.input}
          keyboardType="numeric"
        />
      <Buttonn mode="contained" title="Add" onPress={() => addTodo()}>
        Save
        </Buttonn>
        <ScrollView>
        {todos.map(todo => (
          <TodoList
            key={todo.key}
            todo={todo}
            deleteTodo={deleteTodo}
          />
        ))}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },
  Details:{
    height: 100,
    margin: 12,
    borderWidth: 1,
    padding: 10,
    
  }
});

export default AddTaskScreen;


