import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  Text,
  TextInput,
  View,
  Button,
  ScrollView
} from "react-native";
import AppBar from "../components/AppBar";
import Todo from "../components/Todo";
import TodoList from "../components/TodoList";
import { theme } from "../core/theme";
import Buttonn from "../components/Buttonn";
import AddTaskScreen from "./AddTaskScreen";


export default function App(props) {
  

  const [title, setTitle] = useState("");

  // iniitalize empty object todo
  const [todo, setTodo] = useState({});

  // Initalize empty array to store todos
  const [todos, setTodos] = useState([]);

  // function to add todo object in todo list
  const addTodo = () => {
    if (title.length > 0) {
      // Add todo to the list
      setTodos([...todos, { key: Date.now(), name: title, isChecked: false }]);
      // clear the value of the textfield
      setTitle("");
    }
  };

  // function to mark todo as checked or unchecked
  const checkTodo = id => {
    // loop through todo list and look for the the todo that matches the given id param
    // update the state using setTodos function
    setTodos(
      todos.map(todo => {
        if (todo.key === id) {
          todo.isChecked = !todo.isChecked;
        }
        return todo;
      })
    );
  };

  // function to delete todo from the todo list
  const deleteTodo = id => {
    // loop through todo list and return todos that don't match the id
    // update the state using setTodos function
    setTodos(todos.filter(todo => {
      return todo.key !== id;
    }));
  };
  useEffect(() => {
    console.log(todos.length, "TodoList length");
  }, [todos]);
  return (
    <View style={styles.container}>
      <AppBar
      color={theme.colors.primary}
      />
      <View style={styles.todo}>
        <TextInput
          placeholder="Search task"
          style={styles.textbox}
        />
      </View>
      <ScrollView>

          
      </ScrollView>
      <Buttonn mode="contained" onPress={()=> props.navigation.navigate('AddTask')}>
        create
        </Buttonn>
      <Buttonn mode="outlined" onPress={()=> props.navigation.navigate('Welcome')}>
          Logout
      </Buttonn>
    </View>
  );
}

const styles = StyleSheet.create({
  statusBar: {
    backgroundColor: theme.colors.primary,
    color: "#fff",
    width: "100%",
    height: 30
  },
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "flex-start"
  },
  todo: {
    flexDirection: "row",
    width: "100%",
    justifyContent: "center",
    alignItems: "center"
  },
  textbox: {
    borderWidth: 1,
    borderColor: theme.colors.primary,
    borderRadius: 8,
    padding: 10,
    margin: 10,
    width: "80%"
  }
});
