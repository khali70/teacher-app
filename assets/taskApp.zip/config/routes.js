import React from 'react';
import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import WelcomeScreen from '../screen/WelcomeScreen'
import LoginScreen from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import HomeScreen from '../screens/HomeScreen';
import AddTask from '../screen/AddTaskScreen';
// import ChatScreen from '../screens/ChatScreen';
// import ProfileScreen from '../screens/ProfileScreen';
// import EditProfileScreen from '../screens/EditProfileScreen';
// import PasswordScreen from '../screens/PasswordScreen';

let config = { headerMode: 'none' };
export default createAppContainer(
    createSwitchNavigator({
        Guest: createStackNavigator({
            Welcome:WelcomeScreen,
            Login: LoginScreen,
            Register: RegisterScreen,
        }, config),
        Auth: createStackNavigator({
            Home: HomeScreen,
            AddTaskScreen: AddTask,
            // Chat: ChatScreen,
            // Profile: ProfileScreen,
            // EditProfile: EditProfileScreen,
            // Password: PasswordScreen
        }, config) 
    }, config)
);