import { StatusBar } from 'expo-status-bar';
import 'react-native-gesture-handler';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import React, { Component } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import WelcomeScreen from './screen/WelcomeScreen';
import LoginScreen from './screen/LoginScreen';
import RegisterScreen from './screen/RegisterScreen';
import HomeScreen from './screen/HomeScreen'
import AddTask from './screen/AddTaskScreen';
import { theme } from './core/theme';

const Stack = createStackNavigator();

export default class App extends Component {

  render(){
    return (
      <NavigationContainer>
        <Stack.Navigator
        screenOptions={{
          headerStyle: {
            backgroundColor: theme.colors.primary,
          },
          headerTintColor: '#fff',
        }}
        >          
          
        <Stack.Screen 
        name="Home"
        component={HomeScreen}
        options={{ headerShown: false }}
        /> 
          <Stack.Screen 
          name="Welcome"
          options={{ headerShown: false }}
          component={WelcomeScreen}
          />
          <Stack.Screen 
          name="Login"
          component={LoginScreen}
          />
          <Stack.Screen 
          name="Register"
          component={RegisterScreen}
          />
          <Stack.Screen 
          name="AddTask"
          component={AddTask}
          />

        </Stack.Navigator>
      </NavigationContainer>  
      );
  }

}


